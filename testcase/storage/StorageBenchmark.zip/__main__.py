#!/usr/bin/env python

import time
import unittest
import re
import pkgutil
import tempfile
import sys, os
from pyadb import ADB

adb = ADB("adb")
iozonePath = ""


def platformSDKVersion():
    result = adb.shell_command("getprop ro.build.version.sdk")
    result = re.findall(r"(.*)\r\n", result)
    assert len(result) > 0, "No found platform sdk version."
    sdk = int(result[0])
    return sdk


def printAverageSpeed(header, iozone_result):
    result = iozone_result
    d = {}

    tmp = re.findall(r"Output is in (.*)\r\n", result)
    assert len(tmp) > 0, "No found unit label."
    unitLabel = tmp[0]

    items = re.findall(r'"(.* report)"\r\n\s*(.*)\r\n(.*) \r\n', result)
    assert len(items) > 0, "No found result."

    print "\n+++"
    print header

    nameMap = {
            "Reader report"        : "sequence read",
            "Writer report"        : "sequence write",
            "Random read report"   : "random read",
            "Random write report"  : "random write",
            }

    unitMap = {
            "kBytes/sec" : "KB/s",
            "mBytes/sec" : "MB/s",
            "gBytes/sec" : "GB/s",
            }

    for item in items:
        unit = unitMap[unitLabel]
        name = item[0]
        speeds = item[2].split()[1:]
        speeds = [ int(s) for s in speeds ]
        speed = float(sum(speeds)/len(speeds))
        d[name] = speed

        if name in nameMap:

            while speed > 1024:
                speed = speed/1024
                if unit == "KB/s":
                    unit = "MB/s"
                elif unit == "MB/s":
                    unit = "GB/s"
                    break

            print "\tAverage speed of %s: %.02f %s" % (nameMap[name], speed, unit)

    print "---"


class InternalStorageTestCase(unittest.TestCase):

    def setUp(self):
        self.iozone = "/data/local/tmp/iozone"
        adb.push_local_file(iozonePath, self.iozone)
        adb.shell_command("chmod 0777 %s" % self.iozone)
        self.tmpData = "/data/local/tmp/iozone.tmp"

    def tearDown(self):
        adb.shell_command("rm -f %s" % self.iozone)
        adb.shell_command("rm -f %s" % self.tmpData)

    def testActualSpeed(self):
        cmd = "%s -s 100m -+r -c -p -I -e -r 4k -r 8k -r 16k -r 32k -r 64k -r 128k -r 256k -r 512k -r 1m -r 2m -r 4m -r 8m -r 16m -i 0 -i 1 -i 2 -R -f %s" % (self.iozone, self.tmpData)
        result = adb.shell_command(cmd)

        fname = "result_internal-storage_%s.txt" % time.strftime("%F-%H-%M-%S")
        with open(fname, "w") as f:
            f.write(result)

        printAverageSpeed("Internal phone storage:", result)
        print "Result file: %s" % fname


@unittest.skipIf(platformSDKVersion() >= 23, "Not support platform.")
class ObsoleteSDCardTestCase(unittest.TestCase):

    def setUp(self):
        self.iozone = "/data/local/tmp/iozone"
        adb.push_local_file(iozonePath, self.iozone)
        adb.shell_command("chmod 0777 %s" % self.iozone)

        result = adb.shell_command("echo $SECONDARY_STORAGE")
        result = re.findall(r"(.*)\r\n", result)
        self.assertTrue(len(result) > 0, "No found SECONDARY_STORAGE.")
        self.tmpData = result[0] + "/iozone.tmp"

    def tearDown(self):
        adb.shell_command("rm -f %s" % self.iozone)
        adb.shell_command("rm -f %s" % self.tmpData)

    def testActualSpeed(self):
        cmd = "%s -s 100m -+r -c -p -I -e -r 4k -r 8k -r 16k -r 32k -r 64k -r 128k -r 256k -r 512k -r 1m -r 2m -r 4m -r 8m -r 16m -i 0 -i 1 -i 2 -R -f %s" % (self.iozone, self.tmpData)
        result = adb.shell_command(cmd)

        fname = "result_obsolete-storage_%s.txt" % time.strftime("%F-%H-%M-%S")
        with open(fname, "w") as f:
            f.write(result)

        printAverageSpeed("Obsolete SDCard:", result)
        print "Result file: %s" % fname


@unittest.skipIf(platformSDKVersion() < 23, "Not support platform.")
class PortableSDCardTestCase(unittest.TestCase):

    def setUp(self):
        self.iozone = "/data/local/tmp/iozone"
        adb.push_local_file(iozonePath, self.iozone)
        adb.shell_command("chmod 0777 %s" % self.iozone)

        result = adb.shell_command("sm list-disks")
        disks = re.findall(r"(.*)\r\n", result)
        self.assertTrue(len(disks) > 0, "Please insert SDCard.")

        adb.shell_command("sm partition %s public" % disks[0])

        result = adb.shell_command("sm list-volumes public")
        result = re.findall(r"(public:.*) (.*) (.*)\r\n", result)
        self.assertTrue(len(result) > 0, "No found public SDCard.")

        volume,status,uuid = result[0]
        if status != "mounted":
            adb.shell_command("sm mount %s" % volume)
            self.assertFalse(adb.lastFailed(), "Failed to mount public SDCard.")

        self.tmpData = "/storage/" + uuid + "/iozone.tmp"

    def tearDown(self):
        adb.shell_command("rm -f %s" % self.iozone)
        adb.shell_command("rm -f %s" % self.tmpData)

    def testActualSpeed(self):
        cmd = "%s -s 100m -+r -c -p -I -e -r 4k -r 8k -r 16k -r 32k -r 64k -r 128k -r 256k -r 512k -r 1m -r 2m -r 4m -r 8m -r 16m -i 0 -i 1 -i 2 -R -f %s" % (self.iozone, self.tmpData)
        result = adb.shell_command(cmd)

        fname = "result_portable-storage_%s.txt" % time.strftime("%F-%H-%M-%S")
        with open(fname, "w") as f:
            f.write(result)

        printAverageSpeed("Portable SDCard:", result)
        print "Result file: %s" % fname


@unittest.skipIf(platformSDKVersion() < 23, "Not support platform.")
class InternalSDCardTestCase(unittest.TestCase):

    def setUp(self):
        self.iozone = "/data/local/tmp/iozone"
        adb.push_local_file(iozonePath, self.iozone)
        adb.shell_command("chmod 0777 %s" % self.iozone)

        result = adb.shell_command("sm list-disks")
        disks = re.findall(r"(.*)\r\n", result)
        self.assertTrue(len(disks) > 0, "Please insert SDCard.")

        adb.shell_command("sm partition %s private" % disks[0])
        self.disk = disks[0]

        result = adb.shell_command("sm list-volumes private")
        result = re.findall(r"(private:.*) (.*) (.*)\r\n", result)
        self.assertTrue(len(result) > 0, "No found private SDCard.")

        volume,status,uuid = result[0]
        if status != "mounted":
            adb.shell_command("sm mount %s" % volume)
            self.assertFalse(adb.lastFailed(), "Failed to mount private SDCard.")

        self.tmpData = "/storage/" + uuid + "/iozone.tmp"
        self.uuid = uuid

        result = adb.shell_command("sm list-volumes emulated")
        result = re.findall(r"(emulated:.*) (.*) (.*)\r\n", result)
        self.assertTrue(len(result) > 0, "No found emulated SDCard.")

        volume,status,uuid = result[0]
        if status != "mounted":
            adb.shell_command("sm mount %s" % volume)
            self.assertFalse(adb.lastFailed(), "Failed to mount emulated SDCard.")

    def tearDown(self):
        adb.shell_command("rm -f %s" % self.iozone)
        adb.shell_command("rm -f /data/local/tmp/iozone.tmp")
        adb.shell_command("sm partition %s public" % self.disk)
        adb.shell_command("sm forget %s" % self.uuid)

    def testActualSpeed(self):
        cmd = "%s -s 100m -+r -c -p -I -e -r 4k -r 8k -r 16k -r 32k -r 64k -r 128k -r 256k -r 512k -r 1m -r 2m -r 4m -r 8m -r 16m -i 0 -i 1 -i 2 -R -f %s" % (self.iozone, self.tmpData)
        result = adb.shell_command(cmd)

        fname = "result_internal-storage_%s.txt" % time.strftime("%F-%H-%M-%S")
        with open(fname, "w") as f:
            f.write(result)

        printAverageSpeed("Internal SDCard:", result)
        print "Result file: %s" % fname


def TestSuite():
    testsuite = unittest.TestSuite()
    testsuite.addTest(InternalStorageTestCase("testActualSpeed"))
    testsuite.addTest(ObsoleteSDCardTestCase("testActualSpeed"))
    testsuite.addTest(PortableSDCardTestCase("testActualSpeed"))
    testsuite.addTest(InternalSDCardTestCase("testActualSpeed"))
    return testsuite

if __name__ == "__main__":
    filePath = tempfile.mktemp()
    with open(filePath, "wb") as f:
        f.write(pkgutil.get_data("resources", "iozone"))
    iozonePath = filePath

    adb.wait_for_device()

    print "\n*** Android Storage I/O Test ***"

    unittest.main(defaultTest="TestSuite")
    os.unlink(filePath)

